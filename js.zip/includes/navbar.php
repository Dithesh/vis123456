<div class="header_menuOuter">
        <div class="container">
            <div class="header_nav">
                <div class="nav_brandBox">
                    <a href="index.php">
                        <img src="images/logo.png" class="logo_img img-fluid" alt="">
                    </a>
                </div>
                <div class="nav_menuBar ml-auto">
                    <ul class="list-unstyled">
                        <li><a href="#">Partner with Us</a></li>
                        <li><a href="#">Loan Enquiry</a></li>
                        <li><a href="#">080-30088494</a></li>
                    </ul>
                </div>
                <div class="social_menuBox">
                    <a href="#"><img src="images/facebook.png" alt=""></a>
                    <a href="#"><img src="images/linkedin.png" alt=""></a>
                    <a href="#"><img src="images/youtube.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>