<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1 maximum-scale=1, user-scalable=0">
    <meta name="HandheldFriendly" content="true" />

    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="title" content="">
    <!-- <link rel="icon" href=""> -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap-grid.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap-reboot.min.css" crossorigin="anonymous">

    <!-- owl slider -->
    <link rel="stylesheet" href="assets/owl-carousel/owl.carousel.css" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/owl-carousel/owl.theme.default.css" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="css/animate.css">
    <!-- <link rel="stylesheet" type="text/css" href="css/jquery.simplyscroll.css"> -->
    <!-- google font -->
    <link rel="stylesheet" type="text/css" href="css/jquery.flipster.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    
    <script type="text/javascript" src="js/jquery.js"></script>
    <title>Vistaar</title>
</head>
<body>