<div class="container guidline_box text-right">
        <a href="#">Policies & Guidelines <img src="images/arrow_testimonial.png" alt="arrow"></a>
    </div>
    <div class="container">
        <div class="footerMenuBox">
            <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>About Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Overview</a></li>
                        <li><a href="#">Mission & Vision</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Investors</a></li>
                        <li><a href="#">Partners</a></li>
                    </ul>
                    
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>Products</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Products</a></li>
                        <li><a href="#">Methodology</a></li>
                        <li><a href="#">Impact</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>Our Customer</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Case Studies</a></li>
                        <li><a href="#">Sectors</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>Working at Vistaar</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Vistaar Culture</a></li>
                        <li><a href="#">Openings</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>News & Updates</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Blog</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                    <h5>Contact</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Corporate Office</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>