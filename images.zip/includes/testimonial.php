<div class="container testimonial_boxOuter">
        <span class="topShadow"></span>
        <span class="bottomShadow"></span>
        <div class="testimonial_inner">
            <h3>NEWS & UPDATES</h3>
            <div class="owl-carousel testimonialOuter owl-theme">
                <div class="item testimonials">
                    <div class="row">
                        <div class="col-sm-3">
                            <h2>August 2019</h2>
                        </div>
                        <div class="col-sm-6">
                            <p>Vivriti Capital facilitates Rs.50 crore securitisation deal for Vistaar Financial Services</p>
                            <a href="#">Read More <img src="images/arrow_testimonial.png" alt="arrow"></a>
                        </div>
                    </div>
                </div>
                <div class="item testimonials">
                    <div class="row">
                        <div class="col-sm-3">
                            <h2>August 2019</h2>
                        </div>
                        <div class="col-sm-6">
                            <p>Vivriti Capital facilitates Rs.50 crore securitisation deal for Vistaar Financial Services</p>
                            <a href="#">Read More <img src="images/arrow_testimonial.png" alt="arrow"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>