new Vue({
    el: '#product_menu',
    data: {
        menuHidden: false
    }
  })